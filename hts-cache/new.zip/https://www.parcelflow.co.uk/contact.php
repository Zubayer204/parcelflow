<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link rel="icon" type="image/x-icon" href="images/char.png" />
<meta name="description" content="Register a FREE UK Shipping Address. We consolidate and ship your parcels in the UK, Europe and Internationally at the best possible price. Click for a Quick Quote now!"/>
<title>Contact Us | UK Shipping Address and Depot | Parcel Flow</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="scripts/scripts.js" type="text/javascript"></script>
 
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
 
  ga('create', 'UA-48615823-1', 'parcelflow.co.uk');
  ga('send', 'pageview');
 
</script>
<script type="text/javascript">
//<![CDATA[
var scRec=document.createElement('SCRIPT');
scRec.type='text/javascript';
scRec.src="//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js";
document.getElementsByTagName('head')[0].appendChild(scRec);
//]]>
</script>
 
</head>
 
<body>
<div id="blanket">
  <div class="header">
    <div class="logo"><a href="index.php"><img src="images/logo.png" border="none" alt="logo" /></a></div>
 
 
 
<!-- start form from here post to registration.php -->
 
  <div class="hd_signin">
 
<form name="register" method="post" action="index.php">
 
 
 
      <table width="189" border="0" cellpadding="2" cellspacing="0">
        <tr>
          <td><input name="loginemail" type="text" class="input" id="fname" onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'Enter your email address':this.value;" value="Enter your email address"/></td>
        </tr>
        <tr>
          <td><input name="loginpassword" type="name" class="input" id="fname" onclick="this.value = '';type='password'" onfocus="this.select();type='password'" onblur="this.value=!this.value?'Enter your password':this.value;type='password'" value="Enter your password"/></td>
        </tr>
    <tr>
          <td><input name="login" type="submit" class="login" id="login" value="" onclick="javascript:signin()"/>
            <span class="forgot"><a href="forgot1.php" target="_blank">Forgot Password?</a></span></td>
    </tr>
      </table>
 
 
 
</form>
 
</div>
 
 
 
 
  </div>
  <div class="navigation">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="how-it-works.php">How it works</a></li>
            <li><a href="rewards.php">Rewards</a></li>
      <li><a href="faqs.php">FAQ</a></li>
      <li><a href="signup.php">Signup</a></li>
      <li><a href="quick-quote.php">Quick Quote</a></li>
            <li><a href="blog">Blog</a></li>
             
 
      <li><a href="contact.php" class="active">Contact us</a></li>
    </ul>
  </div>
  <div class="nav_shadow"></div>
         
  
  <div class="welcome">
     
<form name="form1" method="post" action="contact.php" >  
<table width="589" border="0" cellpadding="2" cellspacing="0">
        <tr><h1>Contact Us - We would love to hear from you!</h1></tr>
        <tr><h2>Ask a question, share a comment, join our community</h2></tr>
        <tr><h3>Or why not try our FAQ</h3></tr>
        <tr><h3>We guarantee a response within 24 hours for all queries. </h3></tr>
        <tr><h3>If it is urgent please quote 'Urgent' in the comments and we will get back within 1 working hour - UK 8:00am to 6:00pm</h3></tr>
        <tr><td>Required *</td></tr>
        <tr>
          <td colspan="3"><input name="firstname" type="text" class="contact_input"  onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'First name':this.value;" value="First name"/><span style="vertical-align:middle">&nbsp;*</span></td>
        </tr>
        <tr>
          <td colspan="3"><input name="lastname" type="text" class="contact_input"   onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'Last name':this.value;" value="Last name"/><span style="vertical-align:middle">&nbsp;*</span></td>
        </tr> 
        <tr>
          <td colspan="3"><input name="phone" type="text" class="contact_input"  onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'Telephone number':this.value;" value="Telephone number"/></td>
        </tr> 
        <tr>
          <td colspan="3"><input name="email" type="text" class="contact_input"   onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'Email address':this.value;" value="Email address"/><span style="vertical-align:middle">&nbsp;*</span></td>
        </tr> 
        <tr>
          <td colspan="3"><textarea name="comments" class="textarea_input" onFocus="this.value=''; this.onfocus=null;"/>Enter questions...</textarea></td>
        </tr>
        <tr>
          <td><input name="send" type="submit" class="send_btn" id="send" value="" /></td>
          <!--<td><img style="margin-left:5px;" src="images/contact_phone.png"></td>-->
          <td><img style="margin-left:25px;" src="images/contact_email.png"></td>
          <td></td>
        </tr>
      </table>
      </form>
             
       
  </div>
 
 <div class="right" style="margin-left:-100px; margin-top:20px;">
<img src="images/contact_image.png">
</div>
 
<img src="images/steps.png" style="margin-top:10px;">
 
</div>
<div id="footer"> <a href="index.php">Home</a>    <a href="how-it-works.php">How It Works</a>    <a href="faqs.php">FAQ</a>    <a href="signup.php">Sign Up</a>    <a href="quick-quote.php">Quick quote</a>  <a href="contact.php">Contact
  </a><br />
  Copyright ©2020 Parcel Flow. All Rights Reserved
</body>
</html>