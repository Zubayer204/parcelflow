
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link rel="icon" type="image/x-icon" href="images/char.png" />
<meta name="description" content="Top FAQs for parcel forwarding international."/>
<title>FAQ | UK Shipping Address and Depot | Parcel Flow</title>
<link href="style.css" rel="stylesheet" type="text/css" />


<!-- Start slider section -->
    <link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="style-slider.css" type="text/css" media="screen" />
	<!-- End slider section -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48615823-1', 'parcelflow.co.uk');
  ga('send', 'pageview');

</script>
<script type="text/javascript">
//<![CDATA[
var scRec=document.createElement('SCRIPT');
scRec.type='text/javascript';
scRec.src="//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js";
document.getElementsByTagName('head')[0].appendChild(scRec);
//]]>
</script>
</head>

<body>
<div id="blanket">
  <div class="header">
    <div class="logo"><a href="index.php"><img src="images/logo.png" border="none" alt="logo" /></a></div>


<!-- start form from here post to registration.php -->

  <div class="hd_signin">

<form name="register" method="post" action="index.php">



      <table width="189" border="0" cellpadding="2" cellspacing="0">
        <tr>
          <td><input name="loginemail" type="text" class="input" id="fname" onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'Enter your email address':this.value;" value="Enter your email address"/></td>
        </tr>
        <tr>
          <td><input name="loginpassword" type="name" class="input" id="fname" onclick="this.value = '';type='password'" onfocus="this.select();type='password'" onblur="this.value=!this.value?'Enter your password':this.value;type='password'" value="Enter your password"/></td>
        </tr>
	<tr>
          <td><input name="login" type="submit" class="login" id="login" value="" onclick="javascript:signin()"/>
            <span class="forgot"><a href="forgot1.php" target="_blank">Forgot Password?</a></span></td>
	</tr>
      </table>



</form>

</div>




  </div>
  <div class="navigation">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="how-it-works.php">How it works</a></li>
			<li><a href="rewards.php">Rewards</a></li>
      <li><a href="faqs.php" class="active">FAQ</a></li>
      <li><a href="signup.php">Signup</a></li>
      <li><a href="quick-quote.php">Quick Quote</a></li>
	        <li><a href="blog">Blog</a></li>

      <li><a href="contact.php">Contact us</a></li>
    </ul>
  </div>
  <div class="nav_shadow"></div>
		
 
  <div class="container_1">
    <div class="left">
      <div class="main_container"> <em>FAQ</em> <br /><br />
	<b>What services do you offer?</b>
<br />
	<ul>
	<li>UK Parcel forwarding</li>
	<li>Parcel consolidation (details below)</li>
	<li>Repackaging (over packaged items cost more money to post we repackage and save you money)</li>
	<li>Personal Shopper (tell us what you want and we buy for you)</li>
	<li>Storage </li>
	<li>Letter forwarding</li>
	<li>Depot pick-up service (you can arrange your own courier)</li>
	<li>Gift wrapping service ( Christmas, birthdays or special occasions- we have them all wrapped up)</li>
	</ul>
<br /><br />

	<b>How do I know when my parcels have arrived at Parcel Flow?</b><br />
		Once your parcel has arrived at our depot an email will automatically be sent to you. For further detail please click <a href="how-it-works.php">how-it-works.php</a> <br /><br /><br />
	<b>Can I request additional insurance for my parcel?</b><br />
		Yes. Additional insurance is available to all our members. You can provide any relevant details of additional insurance via email or using the websites parcel notification form.
 <br /><br /><br />
	<b>Can I arrange my own courier?</b><br />
		Absolutely, however Parcel Flow is committed to getting the best rate from our couriers. We work closely with them to ensure our customers gets the best deal possible<br /><br /><br />
	<b>What couriers does Parcel Flow use?</b><br />
		We currently use Parcel Force and DHL, however we strive to get our members the best deal and so will always opt for the cheapest option for you. <br /><br /><br />
	<b>How long do you keep my parcel once it arrives at your depot?</b><br />
		Parcels are normally dispatched on same day turnaround.<br /><br /><br />
	<b>If I have several parcels arriving at Parcel Flow, can I hold off shipping until all have arrived at your depot and ship them together?</b><br />

Yes. We offer parcel consolidation, which can save on courier costs and be more convenient to you.
<br />Minimum charge of £5 and £1.50 for every other parcel consolidated.  Maximum dimensional weight of consolidated parcels of 40KG.  All charges include extra packaging materials.
<br /><br /><br />
<b>How long can a parcel be stored at Parcel Flow?</b><br />
Up to two weeks after arrival we do not charge. Thereafter the weekly charges are as follows:
<br />
<br />&nbsp;&nbsp;£1.50 for a package dimensional weight of 0-10KG.
<br />&nbsp;&nbsp;£2.50 for a package dimensional weight of 10.1-20KG.  
<br />&nbsp;&nbsp;£3.50 for a package dimensional weight of 20.1-30KG.
<br />&nbsp;&nbsp;£5 for a package dimensional weight greater than 30KG.  
<br />
<br/>We do not accept a package dimensional weight of 40KG or over.
<br/>Please note: we only charge these fees as we are a parcel forwarding company with limited storage
<br /><br /><br />
<b>Is there a limit on size and weight that Parcel Flow will handle?</b><br />

Yes. Our current limit for weight is 40KG.
<br /><br /><br />
<b>Do you open parcels?</b><br />

Yes, but only if your parcel is suspected of being prohibited or illegal. For further details on items we will not ship please go to quick quote and click on 'Prohibited Items' tab.
<br /><br /><br />

<b>Are my details confidential and secure?</b><br />

Yes. We make it a priority that member’s details are kept secure and confidential within our company.
<br /><br /><br />
<b>Can I ship to different countries?</b><br />

Yes. If you want a parcel shipped to an address different to the address you have registered, just go to
your account page and click on edit my details then click on change address.
<br /><br /><br />
<b>Can I track my parcel?</b><br />

Absolutely. If you select a service with tracking included. Once we dispatch your parcel an email will be sent to you with your tracking number and link
to courier’s website. This is also accessible on your account page.
<br /><br /><br />
<b>If I sign up to Parcel Flow, do I get a PO box or a real UK address?</b><br />

All our members receive their own unique UK address.
<br /><br /><br />
<b>Will Parcel Flow provide a UK phone number which is mandatory when registering with some online UK retailers?</b><br />

Yes. Once you have signed up to our service you will receive an email with your new unique UK address and
UK telephone number. This phone will be answered by a Parcel Flow member of staff.
<br /><br /><br />
<b>What types of payment do you accept?</b><br />

At present we are only accepting payment through PayPal.
<br /><br /><br />
<b>Do you have a customer loyalty program?</b><br />

Yes we do.  We are proud to be the only parcel forwarding company that offers such a program
<br /><br /><br />


<b>What is the Price Promise Guarantee?</b><br />

We simply guarantee the best prices.  There are no hidden costs and we offer a discounted service to ensure forwarding parcels through us makes financial sense.  Our ‘price promise Guarantee’ allows our members to see if the price quoted by us can be beaten by our competition.  If it does, well then great for you!!  All we require is the pricing information and website address from another parcel forwarder that IS cheaper and is of the same courier standard to ours and we will simply match it and give you FREE handling on your next order.
<br /><br /><br />


<b>Will my invoice include duties/ taxes for my parcel?</b><br />

No. This is separate and is your responsibility.
<br /><br /><br />
<b>Do you deliver to PO boxes?</b><br />

Unfortunately we are unable to as most couriers refuse to due to insurance and security reasons.
<br /><br /><br />
<b>Can I use my UK address to apply for credit cards or legal documents like passports, birth certificates or driver’s license?</b><br />

No. Please be aware if Parcel Flow has reason to suspect unlawful activity from one of its members it
WILL notify the proper authorities.
<br /><br /><br />
<b>Do you have restrictions on volumetric/ dimensional packages?</b><br />

Our volumetric weight restriction is the same as our actual weight restriction of 40kg.
<br /><br /><br />


<b>If I have several parcels arriving at Parcel Flow, can I hold off shipping until all have arrived at your depot and ship them together?</b>
<br />
Yes. We offer parcel consolidation, which can save on courier costs and be more convenient to you. 
<br />Minimum charge of £5 and £1.50 for every other parcel of dimensional weight of consolidated parcels of 10KG.
<br />All charges include extra packaging materials. 
<br />
<br />
10-20 KG  £2.50 per week

<br />
20KG plus we charge  £4.50 per week

<br />
Jiffy bags and padded envelopes our minimum charge is 3.00 plus 1 pound per week.

<br /><br /><br />

<b>What if I need my package quickly, can Parcel Flow source the quickest courier even it is more expensive?</b><br />

Absolutely. In general we will always source the couriers that are best value, however we do understand that sometimes customers will pay extra for quicker delivery.
<br /><br /><br />

Hopefully our FAQ section has answered any questions you may have, however if this is not the case then please get in touch at FAQ@pacelflow.co.uk, our promise is to respond to you within two hours.
<br /><br /><br />
Thank you
<br /><br /><br />
<b>Parcelflow.</b>
       
<img src="images/steps.png">

	</div>
    </div>
   
  </div>
</div>
<div id="footer"> <a href="index.php">Home</a>    <a href="how-it-works.php">How It Works</a>    <a href="faqs.php">FAQ</a>    <a href="signup.php">Sign Up</a>    <a href="quick-quote.php">Quick quote</a>    <a href="contact.php">Contact
  </a><br />
  Copyright © 2020 Parcel Flow. All Rights Reserved
</body>
</html>
