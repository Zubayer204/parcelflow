<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Parcel Flow</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48615823-1', 'parcelflow.co.uk');
  ga('send', 'pageview');

</script>

</head>

<body>
<!-- Google Code for Get A quote Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 971942869;
var google_conversion_language = "en";
var google_conversion_format = "2";
var google_conversion_color = "ffffff";
var google_conversion_label = "xOy6CLvZzgkQ1de6zwM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/971942869/?label=xOy6CLvZzgkQ1de6zwM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<div id="blanket">
  <div class="header">
    <div class="logo"><a href="index.php"><img src="images/logo.png" border="none" alt="logo" /></a></div>
    <!--<div class="character"></div>-->
  </div>
  <div class="container_1">
  <div class="content_hd_basic">Forgot Your Password?</div>
  <div class="content_detail">
  
<form name="register" method="post" action="forgot1.php">

  <table width="980" border="0" align="left" cellpadding="0" cellspacing="6">
  <tr>
    <td colspan="4"><span class="order_hd_s">Enter your new email below. Click the &quot;CONTINUE&quot; button. We will send your password to you.</span></td>
    </tr>
      <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="145">Enter Email Address</td>
    <td width="432"><input name="email" type="text" class="input3" id="textfield2"  onclick="value=''"  /></td>
<font size="1" face="arial" color="red">No email was entered.</font>    <td width="131">&nbsp;</td>
    <td width="242">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="button" type="submit" class="continue_btn" id="button" value=""/></td>

    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>

</table>
</form>  
  </div>
 
  </div>
</div>
<div id="footer"> <a href="index.php">Home</a>    <a href="how-it-works.php">How It Works</a>    <a href="faqs.php">FAQ</a>    <a href="signup.php">Sign Up</a>    <a href="quick-quote.php">Quick quote</a>    <a href="contact.php">Contact
  </a><br />
  Copyright © 2016 Parcel Flow. All Rights Reserved

</body>
</html>

