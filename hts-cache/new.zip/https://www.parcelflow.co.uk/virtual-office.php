<!DOCTYPE html>
<html>
<head>
	<title>Website Name | Official Site</title>
	<link rel="stylesheet" type="text/css" href="virtual/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="virtual/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="virtual/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="virtual/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="virtual/css/style.css">


<meta name="google-site-verification" content="3g8Fm11QAhaRn_Yskm9KP6ectKPpDSbw_fdBvKfDNQ4" />
<link rel="icon" type="image/x-icon" href="images/char.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="keywords" content="parcel forwarding, forwarding service, package forwarding, packet forwarding, uk mailing address, international parcel shipping, uk postal address"/>
<meta name="description" content="
Free UK address for all your UK online purchases if you sign up today. No hidden fees or subscription charges, low cost shipping. Parcel Forwarding from UK to Europe, US, International. Amazon UK, ebay UK and all your favourite UK brands. Will deliver goods internationally.  You shop, we ship.  Parcel Flow UK."/>
<title>UK Shipping Address and Depot | Parcel Forwarding Service| Parcel Flow</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="virtual.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<![CDATA[
var scRec=document.createElement('SCRIPT');
scRec.type='text/javascript';
scRec.src="//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js";
document.getElementsByTagName('head')[0].appendChild(scRec);
]]>
</script>
<script src="scripts/scripts.js" type="text/javascript"></script>


<!-- Start slider section -->
    <link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="style-slider.css" type="text/css" media="screen" />
	<!-- End slider section -->
<script language="text/javascript">


</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48615823-1', 'parcelflow.co.uk');
  ga('send', 'pageview');

</script>



</head>
<body>
	<div class="top-sec">
		<div class="container">
			<div class="row nomargin">
				<img src="virtual/images/header-logo.png" class="img-responsvie">
				<a href="" class="btn btn-login">Login</a>
			</div>
		</div>
	</div>

	<div class="menu-sec">
		<div class="container">
			<nav class="navbar navbar-default">
		    	<!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      	<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				        <span class="sr-only">Toggle navigation</span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				    </button>
			    </div>

		    	<!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			      	<ul class="nav navbar-nav">
				        <li><a href="index.html">HOME</a></li>
				        <li><a href="#">HOW It works</a></li>
				        <li><a href="#">services</a></li>
				        <li><a href="#">rewards</a></li>
				        <li><a href="#">faqs</a></li>
				        <li><a href="#">signup</a></li>
				        <li><a href="#">quick quote</a></li>
				        <li><a href="#">blog</a></li>
				        <li><a href="#">Contact Us</a></li>
			      	</ul>
			    </div><!-- /.navbar-collapse -->
			</nav>
		</div>
	</div>


	<div class="slider-sec">
		<div class="container">
			<img src="virtual/images/virtual-banner.png" class="img-responsive" style="margin-top: -50px">
		</div>
	</div>

	<div class="main-sec">
		<div class="container">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="top-heading">
					<img src="virtual/images/flag-circle.png" class="img-responsive">
					<h5 class="big-heading">Have a big <span style="font-family: 'MyriadPro Black' !important;color: #dc0900">UK Presence</span><br>without big <span style="font-family: 'MyriadPro Black' !important;color: #dc0900">uk bills</span></h5>
					<a href="" class="btn btn-primary">1 MONTH FREE<br>on 12 months contracts</a>
				</div>
			</div>
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="rent">
					<h4>Why pay rent, Insurance and UK rates when you get it here for as little as £6.99 per month!!</h4>
					<p>We offer the cheapest UK business address on the market. All with flexible terms, no big deposits. Compare our prices with our competitors.<br>We have 2 affordable packages to suit all budgets.</p>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-6">
				<div class="band-div">
					<div class="heading1">
						<p>
							<span class="band-title">Gold band</span>
							<span class="band-rate">&pound;12.99/Month Includes</span>
						</p>
					</div>
					<ul class="band-list">
						<li>UK Address</li>
						<li>Letter Forwarding 5 per month FREE</li>
						<li>Small package forwarding with no handling fees</li>
						<li>Scanning Services</li>
						<li class="unstyle"><a href="gold-band.php" class="buy-now">Buy Now</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-6">
				<div class="band-div">
					<div class="heading2">
						<p>
							<span class="band-title">Silver band</span>
							<span class="band-rate">&pound;6.99/Month Includes</span>
						</p>
					</div>
					<ul class="band-list">
						<li>UK Address</li>
						<li>Business letter scanned and emailed</li>
						<li>Small package forwarding</li>
						<li class="unstyle" style="margin-top: 25px;"><a href="silver-band.php" class="buy-now">Buy Now</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>


	<footer class="footer-sec">
		<div class="container">
			<div class="row">
				<div class="footer-menu">
					<ul class="col-md-3 col-sm-3 col-xs-6">
						<li>ABOUT</li>
						<li><a href="">Blog</a></li>
						<li><a href="">feefo reviews</a></li>
						<li><a href="">affiliate program</a></li>
					</ul>
					<ul class="col-md-3 col-sm-3 col-xs-6">
						<li>SERVICES</li>
						<li><a href="">Virtual Office</a></li>
						<li><a href="">bespoke large item shipping</a></li>
						<li><a href="">amazon returns</a></li>
					</ul>
					<ul class="col-md-3 col-sm-3 col-xs-6" >
						<li>LEGAL</li>
						<li><a href="">terms of trade</a></li>
						<li><a href="">terms of use</a></li>
						<li><a href="">privacy</a></li>
					</ul>
					<ul class="col-md-3 col-sm-3 col-xs-6">
						<li>INSURANCE</li>
						<li><a href="">Overview</a></li>
						<li><a href="">summary of cover</a></li>
						<li><a href="">schedule</a></li>
					</ul>
				</div>
			</div>			
		</div>
		<div class="copyright-sec">
			<div class="container">
				<div class="row" style="padding: 15px 0px; ">
					<div class="col-md-8">
						<p style="font-size: 18px; font-weight: bold;">&copy Copyright 2020 Parcel Flow. All Rights Reserved.</p>
						<p style="font-size: 12px;">Parcel Flow, Suite 10, 44-46 Elmwood Ave, Co. Antrim, Belfast, BT9 6AZ, United Kingdom. 
            UK Mailing Address and Parcel Forwarding Service.</p>
					</div>
					<div class="col-md-4">
						<img src="virtual/images/footer-logo.png" class="img-responsive">
					</div>
				</div>
			</div>
		</div>
	</footer>
	


	<!-- Javascripts -->

	<script type="text/javascript" src="virtual/js/jquery-scrolltofixed-min.js"></script>
	<script type="text/javascript" src="virtual/js/jquery.min.js"></script>
	<script type="text/javascript" src="virtual/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="virtual/js/scripts.js"></script>

	
</body>
</html>
