<!DOCTYPE html>
<html>
<head>
	<title>Website Name | Official Site</title>
	<link rel="stylesheet" type="text/css" href="virtual/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="virtual/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="virtual/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="virtual/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="virtual/css/style.css">
</head>
<body>
	<div class="top-sec">
		<div class="container">
			<div class="row nomargin">
				<img src="virtual/images/header-logo.png" class="img-responsvie">
				<a href="" class="btn btn-login">Login</a>
			</div>
		</div>
	</div>

	<div class="menu-sec">
		<div class="container">
			<nav class="navbar navbar-default">
		    	<!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      	<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				        <span class="sr-only">Toggle navigation</span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				    </button>
			    </div>

		    	<!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			      	<ul class="nav navbar-nav">
				        <li><a href="index.html">HOME</a></li>
				        <li><a href="#">HOW It works</a></li>
				        <li><a href="#">services</a></li>
				        <li><a href="#">rewards</a></li>
				        <li><a href="#">faqs</a></li>
				        <li><a href="#">signup</a></li>
				        <li><a href="#">quick quote</a></li>
				        <li><a href="#">blog</a></li>
				        <li><a href="#">Contact Us</a></li>
			      	</ul>
			    </div><!-- /.navbar-collapse -->
			</nav>
		</div>
	</div>


	<div class="slider-sec">
		<div class="container">
			<img src="virtual/images/virtual-banner.png" class="img-responsive" style="margin-top: -50px">
		</div>
	</div>

	<div class="main-sec" style="margin-top: -15px !important;">
		<div class="container">
			<div class="col-md-12 col-sm-12 col-xs-12" style="margin-bottom: 30px;">
				<div class="top-heading">
					<img src="virtual/images/basket.png" class="img-responsive">
					<h5 class="basket-heading">Basket</h5>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-12 band-details">
				<div class="row gold-top-bar">
					<div class="col-md-7">
						<span class="band-title">Silver band</span>
					</div>
					<div class="col-md-5">
						<span class="band-title">Price</span>
					</div>
				</div>
				<div class="row gold-body">
					<div class="col-md-7">
						<div class="col-md-6 nopadding">
							<img src="virtual/images/gold-virtual.png" class="img-responsive" style="margin: auto;">
						</div>
						<div class="col-md-6 left nopadding">
							<address>Suite 10, 44-46 Elwood Avenue,<br>
							Belfast, County Antrim, BT9 6AZ.</address>
							<hr>
							<h5>Mailbox Plus</h5>
							<p><span>Start date:</span>   Thursday 31st of December 2020<br>
							<span>Length of term:</span> 12 Months<br>
							<span>End date:</span> Friday 31st of December 2021</p>
						</div>
					</div>
					<div class="col-md-5 right">
						<p>Monthly rate (ex VAT):             <span> &pound;6.99</span><br>
						One time registration fee:            <span> &pound;15.00</sapn></p>
						<hr>
						<P>Initial Payment:                   <span> &pound;21.99</span></P>
				<a href="business_1.php?band=g" class="btn btn-default">Next</a>					</div>
					<div class="clearfix"></div>
					<div class="btm-lines">
						<p>Promotional discounts will be included in your final agreement where applicable.</p>
						<a href="" style="float: right;">View Virtual office terms and conditions</a>
					</div>
				</div>
			</div>
			<div class="col-md-12" style="text-align: center;margin-top: 110px">
				<a href="" class="btn signup">Signup Today and give us a try!!</a>
				<p class="more-info">For more information Like Our <a href="https://www.facebook.com/">Facebook</a> Page</p>
			</div>
		</div>
	</div>


	<footer class="footer-sec">
		<div class="container">
			<div class="row">
				<div class="footer-menu">
					<ul class="col-md-3 col-sm-3 col-xs-6">
						<li>ABOUT</li>
						<li><a href="">Blog</a></li>
						<li><a href="">feefo reviews</a></li>
						<li><a href="">affiliate program</a></li>
					</ul>
					<ul class="col-md-3 col-sm-3 col-xs-6">
						<li>SERVICES</li>
						<li><a href="">Virtual Office</a></li>
						<li><a href="">bespoke large item shipping</a></li>
						<li><a href="">amazon returns</a></li>
					</ul>
					<ul class="col-md-3 col-sm-3 col-xs-6" >
						<li>LEGAL</li>
						<li><a href="">terms of trade</a></li>
						<li><a href="">terms of use</a></li>
						<li><a href="">privacy</a></li>
					</ul>
					<ul class="col-md-3 col-sm-3 col-xs-6">
						<li>INSURANCE</li>
						<li><a href="">Overview</a></li>
						<li><a href="">summary of cover</a></li>
						<li><a href="">schedule</a></li>
					</ul>
				</div>
			</div>			
		</div>
		<div class="copyright-sec">
			<div class="container">
				<div class="row" style="padding: 15px 0px; ">
					<div class="col-md-8">
						<p style="font-size: 18px; font-weight: bold;">&copy Copyright 2016 Parcel Flow. All Rights Reserved.</p>
						<p style="font-size: 12px;">Parcel Flow, Suite 10, 44-46 Elmwood Ave, Co. Antrim, Belfast, BT9 6AZ, United Kingdom. 
            UK Mailing Address and Parcel Forwarding Service.</p>
					</div>
					<div class="col-md-4">
						<img src="virtual/images/footer-logo.png" class="img-responsive">
					</div>
				</div>
			</div>
		</div>
	</footer>
	


	<!-- Javascripts -->

	<script type="text/javascript" src="virtual/js/jquery-scrolltofixed-min.js"></script>
	<script type="text/javascript" src="virtual/js/jquery.min.js"></script>
	<script type="text/javascript" src="virtual/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="virtual/js/scripts.js"></script>

	
</body>
</html>
