<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Parcel Flow</title>
<link href="style.css" rel="stylesheet" type="text/css" />


<!-- Start slider section -->
    <link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="style-slider.css" type="text/css" media="screen" />
	<!-- End slider section -->


	<link rel="stylesheet" href="style_new.css" type="text/css" media="screen" charset="utf-8" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
<script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
	
	
	
	
<script type="text/javascript" charset="utf-8">
			$(document).ready(function(){
				$("area[rel^='prettyPhoto']").prettyPhoto();
				
				$(".tpop:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal',theme:'light_square',slideshow:3000, autoplay_slideshow: false});
				$(".tpop:gt(0) a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'fast',slideshow:10000, hideflash: true});
		
				$("#custom_content a[rel^='prettyPhoto']:first").prettyPhoto({
					custom_markup: '<div id="map_canvas" style="width:260px; height:265px"></div>',
					changepicturecallback: function(){ initialize(); }
				});

				$("#custom_content a[rel^='prettyPhoto']:last").prettyPhoto({
					custom_markup: '<div id="bsap_1259344" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div><div id="bsap_1237859" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6" style="height:260px"></div><div id="bsap_1251710" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div>',
					changepicturecallback: function(){ _bsap.exec(); }
				});
			});
			</script>
            
            
   <script type="text/javascript" charset="utf-8">
			$(document).ready(function(){
				$("area[rel^='prettyPhoto']").prettyPhoto();
				
				$(".agree:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal',theme:'light_square',slideshow:3000, autoplay_slideshow: false});
				$(".agree:gt(0) a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'fast',slideshow:10000, hideflash: true});
		
				$("#custom_content a[rel^='prettyPhoto']:first").prettyPhoto({
					custom_markup: '<div id="map_canvas" style="width:260px; height:265px"></div>',
					changepicturecallback: function(){ initialize(); }
				});

				$("#custom_content a[rel^='prettyPhoto']:last").prettyPhoto({
					custom_markup: '<div id="bsap_1259344" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div><div id="bsap_1237859" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6" style="height:260px"></div><div id="bsap_1251710" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div>',
					changepicturecallback: function(){ _bsap.exec(); }
				});
			});
			</script>   

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-37474788-10', 'parcelflow.co.uk');
  ga('send', 'pageview');

</script>
			
</head>
















<body>
<div id="blanket">
  <div class="header">
    <div class="logo"><a href="index.php"><img src="images/logo.png" border="none" alt="logo" /></a></div>


<!-- start form from here post to registration.php -->

  <div class="hd_signin">

<form name="register" method="post" action="index.php">



      <table width="189" border="0" cellpadding="2" cellspacing="0">
        <tr>
          <td><input name="loginemail" type="text" class="input" id="fname" onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'Enter your email address':this.value;" value="Enter your email address"/></td>
        </tr>
        <tr>
          <td><input name="loginpassword" type="name" class="input" id="fname" onclick="this.value = '';type='password'" onfocus="this.select();type='password'" onblur="this.value=!this.value?'Enter your password':this.value;type='password'" value="Enter your password"/></td>
        </tr>
	<tr>
          <td><input name="login" type="submit" class="login" id="login" value="" onclick="javascript:signin()"/>
            <span class="forgot"><a href="forgot1.php" target="_blank">Forgot Password?</a></span></td>
	</tr>
      </table>



</form>

</div>




  </div>
  <div class="navigation">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="how-it-works.php">How it works</a></li>
      <li><a href="faqs.php" class="active">FAQ</a></li>
      <li><a href="signup.php">Signup</a></li>
      <li><a href="quick-quote.php">Quick Quote</a></li>
	        <li><a href="blog">Blog</a></li>
      <li><a href="contact.php">Contact us</a></li>
    </ul>
  </div>
  <div class="nav_shadow"></div>
		
 
</div>

<div class="clear"></div>
  
  
  
  
  
  <div class="testback">
<div class="wrapper">
<div class="testcont">
<div class="intro">
At Parcel Flow we pride ourselves on our customer service and ability to get our members the best deal.   We know keeping costs down is very important for our members and work hard ensuring this, so that you return to parcel flow and make it your no. 1 parcel handler.  
Just look at what some of our most recent members had to say.  
</div><!--intro ends-->

<div class="tm">
<h2><span class="flag"><img src="images/flags/United States of America.png" alt="" /></span><span class="date">2019-08-12</span> <span class="com">andy from New York says :</span><div class="clear"></div></h2>

<p>thanks all arrived in good condition </p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Ireland.png" alt="" /></span><span class="date">2018-09-11</span> <span class="com">peter from Ireland says :</span><div class="clear"></div></h2>

<p>Cheers for your help and advice on consolidation- it did keep costs down </p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/United States of America.png" alt="" /></span><span class="date">2017-04-07</span> <span class="com">Buck from New York says :</span><div class="clear"></div></h2>

<p>Great service and thxs again Paul</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Germany.png" alt="" /></span><span class="date">2016-11-11</span> <span class="com">Ben from Germany says :</span><div class="clear"></div></h2>

<p>Dear Parcelflow support, I ordered a package about 2 Weeks ago and just received my order. I am very 
happy about the handling and would like to say thank you. Now I would like to order another package</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Germany.png" alt="" /></span><span class="date">2016-05-05</span> <span class="com">Markus from Munich says :</span><div class="clear"></div></h2>

<p>hi, Guys just would like to confirm shoes arrived and thank you for your service and please keep good work 
up</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Spain.png" alt="" /></span><span class="date">2015-12-02</span> <span class="com">Juan from Madrid says :</span><div class="clear"></div></h2>

<p>Excelente trabajo!!

Muchisinas gracias 
100% RECOMENDABLE </p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Netherlands.png" alt="" /></span><span class="date">2015-12-01</span> <span class="com">Ola from Bergen says :</span><div class="clear"></div></h2>

<p>Brilliant consolidation service and securely packaged. Thx Paul</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Australia.png" alt="" /></span><span class="date">2015-11-27</span> <span class="com">Steve from Sydney says :</span><div class="clear"></div></h2>

<p>Thanks guys are Disney Stuff arrived just in time for daughters birthday. </p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Germany.png" alt="" /></span><span class="date">2015-10-14</span> <span class="com">Merick from Munich says :</span><div class="clear"></div></h2>

<p>Thank you for your assistance with my shoes, cleared customs with no hassle.  Will use again.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/United States of America.png" alt="" /></span><span class="date">2015-07-06</span> <span class="com">Ryan from Dallas says :</span><div class="clear"></div></h2>

<p>Awesome service guys, slick and quick the best :))</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/France.png" alt="" /></span><span class="date">2015-05-11</span> <span class="com">Charles from Paris  says :</span><div class="clear"></div></h2>

<p>Thx guys great job again</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Indonesia.png" alt="" /></span><span class="date">2015-02-02</span> <span class="com">Marcel from indonesia says :</span><div class="clear"></div></h2>

<p>Great job again guys, parcel arrived very quickly and well packaged.  </p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Australia.png" alt="" /></span><span class="date">2014-12-18</span> <span class="com">Dean from Sydney says :</span><div class="clear"></div></h2>

<p>Hi Guys, great service, thanks for  repackaging, it really did save me money. I like the fact you 
do actually try to keep shipping costs down.  Will recommend to friends your service</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/France.png" alt="" /></span><span class="date">2014-11-04</span> <span class="com">Andre from  lyon  says :</span><div class="clear"></div></h2>

<p>Thank you sir for your speedy services.  Love your loyalty points system- 250 points away from £25.00 shipping voucher so will make use over Christmas.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Chile.png" alt="" /></span><span class="date">2014-09-24</span> <span class="com">Benny from Chile says :</span><div class="clear"></div></h2>

<p>Order received. Excellent service. I will spread the word here.
Thanks a lot.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Finland.png" alt="" /></span><span class="date">2014-09-24</span> <span class="com">Kari from Helsinki says :</span><div class="clear"></div></h2>

<p>Have used many Parcel forwarding services  and I can honestly say that Parcelflow is the best. Why? Because 
they are the cheapest, keep me updated all the time, takes my feedback seriously and the\'re always trying to 
get even better. Parcel consolidation service is the best and saves me lots of money comparing to their 
competitors. I\'m very pleased that I found their service and can recommend sincerely to everybody around the 
world.\&quot;</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Australia.png" alt="" /></span><span class="date">2014-09-18</span> <span class="com">Jake from Melbourne says :</span><div class="clear"></div></h2>

<p>Good work, package received yesterday and as for communication updates- always good.  Thanks and will use 
again.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/France.png" alt="" /></span><span class="date">2014-08-11</span> <span class="com">Jerome from France says :</span><div class="clear"></div></h2>

<p>I just wanted to thank you and let you know that I spent about 6 months looking for these shoes as well The shoes are great, well packaged, lightning quick shipping. A real professional operation. Look forward to doing business again with you in the future.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Spain" alt="" /></span><span class="date">2014-06-11</span> <span class="com">JB from Spain says :</span><div class="clear"></div></h2>

<p>Package was just received in good condition earlier today. Thanks for the service. Appreciate it. I surely will use ParcelFlow for future purchases from UK.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/France" alt="" /></span><span class="date">2014-04-27</span> <span class="com">Stephan from France says :</span><div class="clear"></div></h2>

<p>Thank you very much for your email. Fantastic service !.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Ireland" alt="" /></span><span class="date">2014-01-20</span> <span class="com">Claire from Dublin says :</span><div class="clear"></div></h2>

<p> have used Parcel Flow several times now, excellent communication throughout so cheers Parcel Flow and keep up the good work.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Ireland" alt="" /></span><span class="date">2013-12-19</span> <span class="com">Joe from Limerick says :</span><div class="clear"></div></h2>

<p>I signed up only three weeks ago after reading your price promise &amp; have to say good job!! I received my first package quickly and price wise adding the additional costs I still saved money and got exactly what I wanted.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Switzerland" alt="" /></span><span class="date">2013-12-04</span> <span class="com">Michael from Switzerland says :</span><div class="clear"></div></h2>

<p>Great service and good communication. They forwarded a mountain bike for me. The costs were not too bad and I could choose from various shipping methods. </p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Spain" alt="" /></span><span class="date">2013-11-27</span> <span class="com">Seb from Spain says :</span><div class="clear"></div></h2>

<p>Good job &amp; thanks again.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Germany" alt="" /></span><span class="date">2013-11-14</span> <span class="com">John &amp; Deidre (ex-pats) from Cologne says :</span><div class="clear"></div></h2>

<p>Thanks Parcel Flow, will recommend you to our friends &amp; really appreciated your diligence in finding best courier options and relevant updates on packages.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/Ireland.png" alt="" /></span><span class="date">2013-02-28</span> <span class="com">Aidan from Louth says :</span><div class="clear"></div></h2>

<p>This is a great service as I was able to order from the UK sites that normally prohibit me, and have them delivered to the Belfast depot and pick them up personally on my last trip to Belfast. I now shop online with that in mind.</p>

</div><div class="tm">
<h2><span class="flag"><img src="images/flags/France" alt="" /></span><span class="date">2013-02-08</span> <span class="com">Brigette Lyon from France says :</span><div class="clear"></div></h2>

<p>Excellent job, love the easy style and format of site. Very reassuring was your parcel notification form. Thx.</p>

</div>	

	

<div class="tm">
<p style="text-align:center;margin-top:40px;">If you have used our service, please let us know your experiences on service, pricing & anything else.<br /> 
Send your emails to info@parcelflow.co.uk <br />
Thank you,<br />
From Parcel Flow Staff.</p></div>

</div><!--tm ends-->




</div><!--testcont ends-->
</div><!--wrapper ends-->
<div class="clear"></div>
</div><!--testback ends-->
  
  
  
  
  
  
  
  
  

<div id="footer"> <a href="index.php">Home</a>    <a href="how-it-works.php">How It Works</a>    <a href="faqs.php">FAQ</a>    <a href="signup.php">Sign Up</a>    <a href="quick-quote.php">Quick quote</a>    <a href="contact.php">Contact
  </a><br />
  Copyright © 2011-2016 Parcel Flow. All Rights Reserved
</body>
</html>
