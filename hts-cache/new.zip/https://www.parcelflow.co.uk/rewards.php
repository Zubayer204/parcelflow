
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link rel="icon" type="image/x-icon" href="images/char.png" />
<meta name="description" content="Top FAQs for parcel forwarding international."/>
<title>Rewards Page | UK Shipping Address and Depot | Parcel Flow</title>
<link rel="icon" type="image/x-icon" href="images/char.png" />
<meta name="viewport" content="width=device-width" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta content="uk shopping, uk prices, shop the uk, price finder" name="keywords"/>
<meta name="description" content="Click for a Quick Quote now! FREE UK Shipping Address NOW. We consolidate and ship your parcels in the UK, Europe and Internationally at the best possible price."/>
<link href="style2.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryTabbedPanels2.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
var scRec=document.createElement('SCRIPT');
scRec.type='text/javascript';
scRec.src="//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js";
document.getElementsByTagName('head')[0].appendChild(scRec);
//]]>
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48615823-1', 'parcelflow.co.uk');
  ga('send', 'pageview');
</script>
</head>

<body id="rewards-page">
<div id="blanket">
  <div class="header">
    <div class="logo"><a href="index.php"><img src="images/logo.png" border="none" alt="logo" /></a></div>


<!-- start form from here post to registration.php -->

  <div class="hd_signin">

<form name="register" method="post" action="index.php">



      <table width="189" border="0" cellpadding="2" cellspacing="0">
        <tr>
          <td><input name="loginemail" type="text" class="input" id="fname" onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'Enter your email address':this.value;" value="Enter your email address"/></td>
        </tr>
        <tr>
          <td><input name="loginpassword" type="name" class="input" id="fname" onclick="this.value = '';type='password'" onfocus="this.select();type='password'" onblur="this.value=!this.value?'Enter your password':this.value;type='password'" value="Enter your password"/></td>
        </tr>
	<tr>
          <td><input name="login" type="submit" class="login" id="login" value="" onclick="javascript:signin()"/>
            <span class="forgot"><a href="forgot1.php" target="_blank">Forgot Password?</a></span></td>
	</tr>
      </table>



</form>
</div>




  </div>
  <div class="navigation">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="how-it-works.php">How it works</a></li>
			<li><a href="rewards.php" class="active">Rewards</a></li>
      <li><a href="faqs.php" >FAQ</a></li>
      <li><a href="signup.php">Signup</a></li>
      <li><a href="quick-quote.php">Quick Quote</a></li>
	  <li><a href="blog">Blog</a></li>
      <li><a href="contact.php">Contact us</a></li>
    </ul>
  </div>
  <div class="nav_shadow"></div>
	<div class="container_1">
		<div class="left">
			<img src="images/parcelmike.gif" id="parcel-mike" alt="" />
			<span href="#" class="grn-btn">Our Rewards Program</span>
			
			<div class="TabbedPanels" id="TabbedPanels1">
				<ul class="TabbedPanelsTabGroup">
					<li tabindex="0" class="TabbedPanelsTab"><span class="textbold">Earn my points</span></li>
					<li tabindex="0" class="TabbedPanelsTab">Spend my points</li>
					<li tabindex="0" class="TabbedPanelsTab">Terms &amp; Conditions</li>
				</ul>
				<div class="TabbedPanelsContentGroup">
				  <div class="TabbedPanelsContentScroll TabbedPanelsContentVisible">
					<h2>How do I earn my points?</h2>
					<p class="text">Our generous rewards allows our loyal members to earn points as they shop with their favourite online retailers. </p>
					<p class="text">250 points earned for first order(This is the equivalent of £1.25 in shipping credit)</p>
					<p class="text">200 points earned for every order thereafter</p>
					<p class="text">Quick Repeat orders - Parcel Flow must receive and dispatch	at least 4 single orders per month</p>
					<p class="text">200 points per consolidated order - 50 points for each consolidated parcel thereafter. 500 point Maximum on any consolidated order.</p>
					<p class="text">If you refer a friend who completes at least one order with Parcel Flow, you will receive 250 points - please email us for further details</p>	
					<p class="text">Lucky strike ...coming soon</p>			
					<p class="text">For a full list of points check out of points table on the right</p>
					<p class="text">More details can be found by clicking on the 'Spend my points' tab above</p>
				  </div>
				  
				  <div class="TabbedPanelsContent">
					<h2>How do I spend my points?</h2>
					<p class="text">There are 3 simple ways to cash in:</p>
					<p class="text">1. 2000 points will give you FREE handling</p>
					<p class="text">2. 5000 points will give FREE shipping up to £25 shipping voucher</p>
					<p class="text">3. 10000 points will give FREE shipping up to £50 shipping voucher</p>	 
					<p class="text">All points are based on our Terms &amp; Conditions.  </p>		
				  </div>
				  <div class="TabbedPanelsContentScroll">
					<h2>Our Terms of Trade for the Loyalty Program</h2>
					<p class="text">Loyalty points cannot be moved between accounts</p>
					<p class="text">Points can only spent on this website and have no numerical value outside of this site.</p>
					<p class="text">£50.00 is the maximum courier value. Members will be responsible for extra carriage costs past this amount and billed accordingly.</p>
					<p class="text">Free courier is given to members who have saved an appropriate amount of points for either £25 or £50 pound carriage costs. </p>
					<p class="text">Courier value is only usable on parcel flow website and through member account.</p>
					<p class="text">Couriers are only booked through Parcel Flow.</p>
					<p class="text">All points are controlled by Parcel Flow.</p>
					<p class="text">Members will accept Parcel Flow decision on disputes as final.</p>
					<p class="text">Members will allow 5 business days for disputes to be resolved.</p>
					<p class="text">If at any time Parcel Flow limits, cancels or stops the loyalty program, members cannot take any further action, and they accept that their points have no numerical value and have no property rights.</p>
					<p class="text">Parcel Flow can alter amounts on consolidation, refer a friend and orders at any time, to reduce,increase or double on limited time offers at their pleasure.</p>
					<p class="text">If Parcel Flow ceases trading or goes into administration, Parcel Flow will have no responsibility, financially or otherwise to members for earned points</p>
					<p class="text">If Parcel Flow is sold, new owners will have final say on whether to continue with the loyalty program and will not be obligated to any member to do so.</p>
					<p class="text">By using this website you accept these conditions.</p>	  
				  </div>
				</div>
			</div>
			
<!--			<div class="buts"><a href="signup.html"><img src="images/referbutton.png" /></a> &nbsp; &nbsp; <a href="#"><img src="images/signupforfree.png" /></a> &nbsp; &nbsp; <a href="#" class="chk-bal"><img src="images/signin.png" /></a></div> 
			<span class="ern-pnts">earn 250 points now!</span>-->
		</div>
		
		<div class="right">
			<div id="rewards-table">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<thead><tr><th colspan="2">POINTS MENU</th></tr></thead>
					<tbody>
						<tr><td>First time order</td><td>250</td></tr>
						<tr><td>Every other order</td><td>200</td></tr>
						<tr><td>Quick repeat</td><td>250</td></tr>
						<tr><td>Parcel Consoldation</td><td>200 minimum</td></tr>
						<tr><td>Refer a friend</td><td>250</td></tr>
						<tr><td>Lucky Strike</td><td>1000</td></tr>
					</tbody>
					<tfoot><tr><td colspan="2">SEE FAQ FOR DETAILS</td></tr></tfoot>
				</table>
			</div>
		</div>
	</div>
</div>
<div id="footer"> <a href="index.php">Home</a>    <a href="how-it-works.php">How It Works</a>    <a href="faqs.php">FAQ</a>    <a href="signup.php">Sign Up</a>    <a href="quick-quote.php">Quick quote</a>    <a href="contact.php">Contact
  </a><br />
  Copyright © 2011-2016 Parcel Flow. All Rights Reserved</div>
  <script type="text/javascript">var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");</script>
</body>
</html>
