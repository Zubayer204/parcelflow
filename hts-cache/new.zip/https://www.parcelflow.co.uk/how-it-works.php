<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="icon" type="image/x-icon" href="images/char.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta content="package forwarding, mail forwarding, customer reviews parcel flow, uk address, uk shopping, global ecommerce" name="keywords"/>
<meta name="description" content="A step by step guide on how to buy from any UK website from any country in the world."/>
<title>How it Works | UK Shipping Address and Depot | Parcel Forwarding</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="scripts/scripts.js" type="text/javascript"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48615823-1', 'parcelflow.co.uk');
  ga('send', 'pageview');

</script>
<script type="text/javascript">
//<![CDATA[
var scRec=document.createElement('SCRIPT');
scRec.type='text/javascript';
scRec.src="//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js";
document.getElementsByTagName('head')[0].appendChild(scRec);
//]]>
</script>
</head>

<body>
<div id="blanket">
  <div class="header">
    <div class="logo"><a href="index.php"><img src="images/logo.png" border="none" alt="logo" /></a></div>




<!-- start form from here post to registration.php -->

  <div class="hd_signin">

<form name="register" method="post" action="index.php">



      <table width="189" border="0" cellpadding="2" cellspacing="0">
        <tr>
          <td><input name="loginemail" type="text" class="input" id="fname" onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'Enter your email address':this.value;" value="Enter your email address"/></td>
        </tr>
        <tr>
          <td><input name="loginpassword" type="name" class="input" id="fname" onclick="this.value = '';type='password'" onfocus="this.select();type='password'" onblur="this.value=!this.value?'Enter your password':this.value;type='password'" value="Enter your password"/></td>
        </tr>
	<tr>
          <td><input name="login" type="submit" class="login" id="login" value="" onclick="javascript:signin()"/>
             <span class="forgot"><a href="forgot1.php" target="_blank">Forgot Password?</a></span>
						</td>
	</tr>
      </table>



</form>

</div>




  </div>
  <div class="navigation">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="how-it-works.php" class="active">How it works</a></li>
			<li><a href="rewards.php">Rewards</a></li>
      <li><a href="faqs.php">FAQ</a></li>
      <li><a href="signup.php">Signup</a></li>
      <li><a href="quick-quote.php">Quick Quote</a></li>
	        <li><a href="blog">Blog</a></li>

      <li><a href="contact.php">Contact us</a></li>
    </ul>
  </div>
  <div class="nav_shadow"></div>


<div class="welcome">

<h1>Your 4 easy steps to forwarding your UK online purchases to anywhere in the world at the cheapest cost to you!</h1>


</div>


  <br />
  <br />
  <br />



    <div class="left">
      <div class="main_container">

<div id="hiw_g1" onclick="hiw1();"><img src="images/hiw_g1.png"></div><div id="hiw_o1"><img src="images/hiw_o1.png"></div>
<div id="hiw_g2" onclick="hiw2();"><img src="images/hiw_g2.png"></div><div id="hiw_o2"><img src="images/hiw_o2.png"></div>
<div id="hiw_g3" onclick="hiw3();"><img src="images/hiw_g3.png"></div><div id="hiw_o3"><img src="images/hiw_o3.png"></div>
<div id="hiw_g4" onclick="hiw4();"><img src="images/hiw_g4.png"></div><div id="hiw_o4"><img src="images/hiw_o4.png"></div>

	</div>
   </div>

 <div class="right" style="margin-left:-340px; margin-top:0px;">
<div id="hiw_step1">
<!-- YOU CAN ADD CONTENT FOR STEP1 HERE-->
<!--<div class="youtube" id="8-VOA1gzt_s" style="width: 500px; height: 305px;"></div>
<script src="https://labnol.googlecode.com/files/youtube.js"></script>-->
<iframe width="500" height="305" src="https://www.youtube.com/embed/dudgT_Ja-cs" frameborder="0" allowfullscreen></iframe>
</div>
<div id="hiw_step2">
<!-- YOU CAN ADD CONTENT FOR STEP2 HERE--><iframe width="500" height="305" src="https://www.youtube.com/embed/dudgT_Ja-cs" frameborder="0" allowfullscreen></iframe>
</div>
<div id="hiw_step3">
<!-- YOU CAN ADD CONTENT FOR STEP3 HERE--><iframe width="500" height="305" src="https://www.youtube.com/embed/dudgT_Ja-cs" frameborder="0" allowfullscreen></iframe>
</div>
<div id="hiw_step4">
<!-- YOU CAN ADD CONTENT FOR STEP4 HERE--><iframe width="500" height="305" src="https://www.youtube.com/embed/dudgT_Ja-cs" frameborder="0" allowfullscreen></iframe>
</div>
</div>

<div class="welcome">
  <br />

  <h2>Step 1 Get a UK Address</h2>
<p>
Simply take a couple of minutes to join our website. There is no membership charges and your account will include your UK shipping address and phone number provided by us at Parcel Flow. Remember you will be joining the only FREE UK address provider for all your online shopping.
</p>
<h2>Step 2 Shop all stores</h2>
<p>
Now shop all your favourite UK online stores such as Amazon UK & eBay and use your UK forwarding address provided by Parcel Flow for all your deliveries.
</p>
<h2>Step 3 Get email notification</h2>
<p>
Once your parcel(s) arrives at our depot, your parcelflow handler will email you. This

email will provide a link to your account where you will find details of best shipping &

insurance options based on price & speed. Once you have made your courier & insurance

choices, you simply pay through Paypal, the worlds safest online payment website.
</p>
<h2>Step 4 Receive packages anywhere</h2>
</p>
Once you have decided on best forwarding options then we do the rest. We simply

forward from the UK to anywhere in the world. All you have to do is sit back and wait for delivery of your

new online purchases, whether its that new iphone you have always wanted or some UK

branded foods, parcelflow aims to allow its member to always shop without restrictions.
</p>

<h2>More information on our services at Parcel Flow</h2>
<!--	  <h2 class="heading_1">How Parcel Forwarding from the UK works</h2>
	  <p class="heading_1">
Simply register, use our UK parcel forwarding address for your online delivery destination. You will receive an email once it arrives at our UK depot,
choose your best courier option (Cheapest first) then sit back and we do the rest. We really do solve the old <b>‘UK shipping only’</b> problem,
with little extra cost and in a friendly, efficient way with an easy to use site.   Our team are always there to answer your emails, update your order status
and notify you on all relevant parcel updates. Why not check out our video now for a quick demo
</p>-->
	  <h2 class="heading_1">
Parcels and packages forwarded from the UK to any destination in the world including Ireland, Germany, Switzerland, France, China and Brazil.</h2>
<p class="heading_1">
We have partnered with several leading courier companies to deliver and to give our customers a reason to come back to us time and time again.
</p>
	  <h2 class="heading_1">Purchase from all the leading UK retailers such as Amazon UK, Ebay UK, Westfield, John Lewis and many more..</h2>
<p class="heading_1">
We have a unique way of doing things - the parcel flow way.  It's how we Innovate, Collaborate and operate.  The Parcel Flow way is brought to life every day,
in everything we do, through our unique, passion, energy and style.
We aim to offer our customers with high quality and fairly priced services. Start today by signing up for your free UK shipping address and follow our simple 3 step process.
</p>


 </div>

  </div>
</div>





<div id="footer"> <a href="index.php">Home</a>    <a href="how-it-works.php">How It Works</a>    <a href="faqs.php">FAQ</a>    <a href="signup.php">Sign Up</a>    <a href="quick-quote.php">Quick quote</a>    <a href="contact.php">Contact
  </a><br />
  Copyright ©2020 Parcel Flow. All Rights Reserved
</body>
</html>
