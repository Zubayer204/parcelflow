<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>FREE Sign Up | Unique UK Shipping Address | Parcel Flow</title>
<link rel="icon" type="image/x-icon" href="images/char.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="Sign up and Register for a FREE UK Shipping Address with Parcel Flow and we forward your parcel in the UK, Europe and Internationally. No hidden service fees.">
<title>FREE Sign Up | Unique UK Shipping Address | Parcel Flow</title>
<link rel="stylesheet" href="style.css" type="text/css" media="screen" charset="utf-8" />

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js" type="text/javascript"></script>

<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
		
<script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-37474788-10', 'parcelflow.co.uk');
  ga('send', 'pageview');

</script>
<script type="text/javascript">
//<![CDATA[
var scRec=document.createElement('SCRIPT');
scRec.type='text/javascript';
scRec.src="//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js";
document.getElementsByTagName('head')[0].appendChild(scRec);
//]]>
</script>

</head>

<script type="text/javascript" charset="utf-8">
			$(document).ready(function(){
				$("area[rel^='prettyPhoto']").prettyPhoto();
				
				$(".tpop:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal',theme:'light_square',slideshow:3000, autoplay_slideshow: false});
				$(".tpop:gt(0) a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'fast',slideshow:10000, hideflash: true});
		
				$("#custom_content a[rel^='prettyPhoto']:first").prettyPhoto({
					custom_markup: '<div id="map_canvas" style="width:260px; height:265px"></div>',
					changepicturecallback: function(){ initialize(); }
				});

				$("#custom_content a[rel^='prettyPhoto']:last").prettyPhoto({
					custom_markup: '<div id="bsap_1259344" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div><div id="bsap_1237859" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6" style="height:260px"></div><div id="bsap_1251710" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div>',
					changepicturecallback: function(){ _bsap.exec(); }
				});
			});
			</script>
            
            
   <script type="text/javascript" charset="utf-8">
			$(document).ready(function(){
				$("area[rel^='prettyPhoto']").prettyPhoto();
				
				$(".agree:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal',theme:'light_square',slideshow:3000, autoplay_slideshow: false});
				$(".agree:gt(0) a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'fast',slideshow:10000, hideflash: true});
		
				$("#custom_content a[rel^='prettyPhoto']:first").prettyPhoto({
					custom_markup: '<div id="map_canvas" style="width:260px; height:265px"></div>',
					changepicturecallback: function(){ initialize(); }
				});

				$("#custom_content a[rel^='prettyPhoto']:last").prettyPhoto({
					custom_markup: '<div id="bsap_1259344" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div><div id="bsap_1237859" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6" style="height:260px"></div><div id="bsap_1251710" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div>',
					changepicturecallback: function(){ _bsap.exec(); }
				});
			});
			</script>         

</head>


<body>
<div id="blanket">
  <div class="header">
    <div class="logo"><a href="index.php"><img src="images/logo.png" border="none" alt="logo" /></a></div>
    <!--<div class="character"></div>-->

  </div>
  <div class="navigation">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="how-it-works.php">How it works</a></li>
      <li><a href="faqs.php">FAQ</a></li>
      <li><a href="signup.php" class="active">Signup</a></li>
      <li><a href="quick-quote.php">Quick Quote</a></li>
	        <li><a href="blog">Blog</a></li>
			<li><a href="rewards.php">Rewards</a></li>
      <li><a href="contact.php">Contact us</a></li>
    </ul>
  </div>
  <div class="nav_shadow"></div>
		
<div id="steps_br">
<img src="images/signupst1.gif">
</div>

  <div class="nav_shadow"></div>
 
  <div class="container_1">
   


<div id="allforms">
<!-- start form from here post to registration.php -->

<form name="register" method="post" action="signup.php">

<!--
<div id="su_1"><img src="images/su_1.png"></div>

-->
</div>

<!-- <div id="su_2"><img src="images/su_2.png"></div> -->

<!-- <div id="su_o2"> -->
<div class="welcome">
<table width="900" border="0" cellpadding="0" cellspacing="0">

		<tr><h1>Signup</h1></tr>
		<tr><h2>Get Started with a Free Account<h2></tr>
<tr><h3>Sign up in 30 seconds. No credit card required. If you already have a Parcel Flow account, log in.</h3></tr>
        <tr>
          <td width="160"><span class="texts"><b>Enter Email:</b></span></td><td width="290"><input name="email" type="text" class="contact_input" value="" /></td>
          <td width="290"><span class="texts"><b>Confirm Email:</b></span></td><td width="290"><input name="email2" type="text" class="contact_input" value="" /></td>
        </tr>

<tr>
<td align="left" colspan="2">

<font size="1" face="arial" color="white" align="top" span style="line-height:16px;">.</font>
</td><td align="left" colspan="2"><font size="1" face="arial" color="red" align="top" span style="line-height:16px"></font></td>
</tr>


        <tr>
          <td  width="160"><span class="texts"><b>Password:</b></span></td><td><input name="password" type="password" class="contact_input" id="input13" /></td>
          <td width="290"><span class="texts"><b>Confirm Password:</b></span></td><td><input name="password2" type="password" class="contact_input" id="input14" /></td>
        </tr>

<tr>
<td align="left" colspan="4">
          <div class="agree"><br /><br/>
          <label for="terms"><input id="terms" type="checkbox" name="terms" value="1" class="required" aria-required="true" required="required" style="margin-right:8px;">I have read and agree to the parcel flow Terms of Trade - <a href="terms.html?iframe=true&amp;width=94%&amp;height=650" rel="prettyPhoto[iframe]">Terms & Privacy</a> <span class="text-error">*</span></label><br /><br/><br/>
		</div><!-- agree ends -->
       </td>   
</tr>

<tr>
<td align="left" colspan="2">

<font size="1" face="arial" color="white" align="top" span style="line-height:16px;">.</font>
</td><td align="left" colspan="2"><font size="1" face="arial" color="red" align="top" span style="line-height:16px"></font></td>
</tr>

<tr align="left" colspan="2">
<td>
<input type="submit" class="signup_btn" name="submit" value="" />
</td>
</tr>




      </table>
      </div>




<!-- <input name="signup" type="submit" class="signup_btn" id="signup" value="" onclick="registration();"/> -->



<br /><br />





</div>



</div>

<div id="thanking" style="display:none;">

<bigfont>Thank you for choosing Parcelflow</bigfont>
<br /><br/>
We have mailed you the login details. Kindly check your mail for further information.

</div>

</form>
   
  </div>
</div>
<div id="footer"> <a href="index.php">Home</a>    <a href="how-it-works.php">How It Works</a>    <a href="faqs.php">FAQ</a>    <a href="signup.php">Sign Up</a>    <a href="quick-quote.php">Quick quote</a>    <a href="contact.php">Contact
  </a><br />
  Copyright © 2011-2016 Parcel Flow. All Rights Reserved
</body>
</html>



