

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="icon" type="image/x-icon" href="images/char.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta content="uk shopping, uk prices, shop the uk, price finder" name="keywords"/>
<meta name="description" content="Click for a Quick Quote now! FREE UK Shipping Address NOW. We consolidate and ship your parcels in the UK, Europe and Internationally at the best possible price."/>
<title>Quick Quote | UK Shipping Address and Depot | Parcel Flow</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
//<![CDATA[
var scRec=document.createElement('SCRIPT');
scRec.type='text/javascript';
scRec.src="//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js";
document.getElementsByTagName('head')[0].appendChild(scRec);
//]]>
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-37474788-10', 'parcelflow.co.uk');
  ga('send', 'pageview');

</script>


</head>

<body>
<!-- Google Code for Get A quote Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 971942869;
var google_conversion_language = "en";
var google_conversion_format = "2";
var google_conversion_color = "ffffff";
var google_conversion_label = "xOy6CLvZzgkQ1de6zwM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/971942869/?label=xOy6CLvZzgkQ1de6zwM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<div id="blanket">
  <div class="header">
    <div class="logo"><a href="index.php"><img src="images/logo.png" border="none" alt="logo" /></a></div>

	

<!-- start form from here post to registration.php -->

  <div class="hd_signin">

  
<form name="register" method="post" action="index.php">



      <table width="189" border="0" cellpadding="2" cellspacing="0">
        <tr>
          <td><input name="loginemail" type="text" class="input" id="fname" onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'Enter your email address':this.value;" value="Enter your email address"/></td>
        </tr>
        <tr>
          <td><input name="loginpassword" type="name" class="input" id="fname" onclick="this.value = '';type='password'" onfocus="this.select();type='password'" onblur="this.value=!this.value?'Enter your password':this.value;type='password'" value="Enter your password"/></td>
        </tr>
	<tr>
          <td><input name="login" type="submit" class="login" id="login" value="" onclick="javascript:signin()"/>
            <span class="forgot"><a href="forgot1.php" target="_blank">Forgot Password?</a></span></td>
	</tr>
      </table>



</form>

</div>




  </div>
  <div class="navigation">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="how-it-works.php">How it works</a></li>
			<li><a href="rewards.php">Rewards</a></li>
			<li><a href="faqs.php">FAQ</a></li>
      <li><a href="signup.php">Signup</a></li>
      <li><a href="quick-quote.php" class="active">Quick Quote</a></li>
	        <li><a href="blog">Blog</a></li>
      <li><a href="contact.php">Contact us</a></li>
    </ul>
  </div>
  
  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="images/shipping-from-as-little-as-990-lowest-prices.gif" alt="register now and save on handling charges" align="middle" border="0" width="50%" height="50%">
  
 <!-- <div class="nav_shadow"></div> -->
<form name="register" method="post" action="quick-quote.php">
  <div class="container_1">

  
  
        <div class="panel_container">

        
        <div class="panel_lft"></div>
		
	 
        <div class="panel_mid">        

		
		<div id="TabbedPanels1" class="TabbedPanels">
		
            <ul class="TabbedPanelsTabGroup">
              <li class="TabbedPanelsTab" tabindex="0">Shipping Rate Calculator</li>
              <li class="TabbedPanelsTab" tabindex="0">Prohibited Items</li>
              <li class="TabbedPanelsTab" tabindex="0">Transit Times</li>
              <li class="TabbedPanelsTab" tabindex="0">Duty / Tax info</li>
            </ul>
			
		
            <div class="TabbedPanelsContentGroup">
              <div class="TabbedPanelsContent">
              <div class="rate_calculator"><table width="650" border="0" align="left" cellpadding="0" cellspacing="6">
  <tr>
    <td width="500">&nbsp;</td>
    <td width="50">&nbsp;</td>
    <td width="50" colspan="3" rowspan="9">
    <img src="images/globe.jpg" border="none" alt="Globe" width="189" height="197" align="right" />
    </td>
    </tr>
  <tr>
    <td><strong><em>Shipping to</em></strong></td>
    <td>

			<select name="country" class="contact_input" id="input1">

			  <option value="Destination" selected="selected">Destination</option>
<option value="Ireland Republic of">Ireland</option>
<option value="USA">USA</option>
<option value="Australia">Australia</option>
<option value="China">China</option>
<option value="Canada">Canada</option>
<option value="France - Paris">France - Paris</option>
<option value="France All other locations">France - All other locations</option>
<option value="Germany All Other Locations">Germany</option>
<option value="Greece">Greece</option>
<option value="Italy">Italy</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Spain">Spain</option>
<option value="" disabled="">--------------</option>
<option value="Afghanistan">Afghanistan</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="American Samoa">American Samoa</option>
<option value="Andorra">Andorra</option>
<option value="Angola">Angola</option>
<option value="Anguilla">Anguilla</option>
<option value="Antigua">Antigua</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Aruba">Aruba</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Bangladesh">Bangladesh</option>
<option value="Barbados">Barbados</option>
<option value="Belarus">Belarus</option>
<option value="Belgium">Belgium</option>
<option value="Belize">Belize</option>
<option value="Benin">Benin</option>
<option value="Bermuda">Bermuda</option>
<option value="Bhutan">Bhutan</option>
<option value="Bolivia">Bolivia</option>
<option value="Bonaire">Bonaire</option>
<option value="Bosnia Herzegovina">Bosnia Herzegovina</option>
<option value="Botswana">Botswana</option>
<option value="Brazil">Brazil</option>
<option value="Brunei">Brunei</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Burkina Faso">Burkina Faso</option>
<option value="Burundi">Burundi</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Canada">Canada</option>
<option value="Canary Islands">Canary Islands</option>
<option value="Cape Verde Islands">Cape Verde Islands</option>
<option value="Caroline Islands">Caroline Islands</option>
<option value="Cayman Islands">Cayman Islands</option>
<option value="Central African Rep.">Central African Rep.</option>
<option value="Chad">Chad</option>
<option value="Chile">Chile</option>
<option value="China People's Rep.">China People's Rep.</option>
<option value="Chuuk Island">Chuuk Island</option>
<option value="Colombia">Colombia</option>
<option value="Comoros Islands">Comoros Islands</option>
<option value="Congo">Congo</option>
<option value="Congo">Congo</option>
<option value="Cook Islands">Cook Islands</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Croatia">Croatia</option>
<option value="Cuba">Cuba</option>
<option value="Curacao">Curacao</option>
<option value="Cyprus">Cyprus</option>
<option value="Czech Republic">Czech Republic</option>
<option value="Denmark">Denmark</option>
<option value="Djibouti">Djibouti</option>
<option value="Dominica">Dominica</option>
<option value="Dominican Rep.">Dominican Rep.</option>
<option value="East Timor">East Timor</option>
<option value="Ebeye Island">Ebeye Island</option>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Equatorial Guinea">Equatorial Guinea</option>
<option value="Eritrea">Eritrea</option>
<option value="Estonia">Estonia</option>
<option value="Ethiopia">Ethiopia</option>
<option value="Falkland Islands">Falkland Islands</option>
<option value="Faroe Islands">Faroe Islands</option>
<option value="Fiji">Fiji</option>
<option value="Finland">Finland</option>
<option value="France - Paris">France - Paris</option>
<option value="France All Other Locations">France All Other Locations</option>
<option value="French Guiana">French Guiana</option>
<option value="Gabon">Gabon</option>
<option value="Gambia">Gambia</option>
<option value="Georgia">Georgia</option>
<option value="Germany - Cologne">Germany - Cologne</option>
<option value="Germany - Frankfurt">Germany - Frankfurt</option>
<option value="Germany All Other Locations">Germany All Other Locations</option>
<option value="Ghana">Ghana</option>
<option value="Gibraltar">Gibraltar</option>
<option value="Greece">Greece</option>
<option value="Greenland">Greenland</option>
<option value="Grenada">Grenada</option>
<option value="Guadeloupe">Guadeloupe</option>
<option value="Guam">Guam</option>
<option value="Guam">Guam</option>
<option value="Guatemala">Guatemala</option>
<option value="Guernsey">Guernsey</option>
<option value="Guinea Rep.">Guinea Rep.</option>
<option value="Guinea-Bissau">Guinea-Bissau</option>
<option value="Guyana">Guyana</option>
<option value="Haiti">Haiti</option>
<option value="Honduras Rep.">Honduras Rep.</option>
<option value="Hong Kong">Hong Kong</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="India">India</option>
<option value="Indonesia">Indonesia</option>
<option value="Iran">Iran</option>
<option value="Iraq">Iraq</option>
<option value="Ireland Republic of">Ireland Republic of</option>
<option value="Isle of Mann">Isle of Mann</option>
<option value="Isles of Scilly">Isles of Scilly</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Ivory Coast">Ivory Coast</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Jersey">Jersey</option>
<option value="Jordan">Jordan</option>
<option value="Kazakhstan">Kazakhstan</option>
<option value="Kenya">Kenya</option>
<option value="Kiribati">Kiribati</option>
<option value="Korea">Korea</option>
<option value="Korea">Korea</option>
<option value="Koror Island">Koror Island</option>
<option value="Kosrae Island">Kosrae Island</option>
<option value="Kuwait">Kuwait</option>
<option value="Kyrgyzstan">Kyrgyzstan</option>
<option value="Laos Peoples Dem. Rep">Laos Peoples Dem. Rep</option>
<option value="Latvia">Latvia</option>
<option value="Lebanon">Lebanon</option>
<option value="Lesotho">Lesotho</option>
<option value="Liberia">Liberia</option>
<option value="Libya">Libya</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Macau">Macau</option>
<option value="Macedonia">Macedonia</option>
<option value="Madagascar">Madagascar</option>
<option value="Majuro Island">Majuro Island</option>
<option value="Malawi">Malawi</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Manua Island">Manua Island</option>
<option value="Marshall Islands">Marshall Islands</option>
<option value="Martinique">Martinique</option>
<option value="Mauritania">Mauritania</option>
<option value="Mauritius">Mauritius</option>
<option value="Mayotte">Mayotte</option>
<option value="Mexico">Mexico</option>
<option value="Micronesia">Micronesia</option>
<option value="Moldova">Moldova</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Montenegro">Montenegro</option>
<option value="Montserrat">Montserrat</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Myanmar (Burma)">Myanmar (Burma)</option>
<option value="Namibia">Namibia</option>
<option value="Nauru">Nauru</option>
<option value="Nepal">Nepal</option>
<option value="Netherlands">Netherlands</option>
<option value="Netherlands Antilles">Netherlands Antilles</option>
<option value="Nevis">Nevis</option>
<option value="New Caledonia">New Caledonia</option>
<option value="New Zealand">New Zealand</option>
<option value="Nicaragua">Nicaragua</option>
<option value="Niger">Niger</option>
<option value="Nigeria">Nigeria</option>
<option value="Niue">Niue</option>
<option value="Northern Ireland">Northern Ireland</option>
<option value="Norway">Norway</option>
<option value="Oman">Oman</option>
<option value="Orkney Isles">Orkney Isles</option>
<option value="Pakistan">Pakistan</option>
<option value="Palau">Palau</option>
<option value="Panama">Panama</option>
<option value="Papua New Guinea">Papua New Guinea</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Philippines">Philippines</option>
<option value="Pohnpei Island">Pohnpei Island</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Puerto Rico">Puerto Rico</option>
<option value="Qatar">Qatar</option>
<option value="Reunion">Reunion</option>
<option value="Romania">Romania</option>
<option value="Rota Island">Rota Island</option>
<option value="Rwanda">Rwanda</option>
<option value="Saipan">Saipan</option>
<option value="Samoa">Samoa</option>
<option value="San Marino">San Marino</option>
<option value="Sao Tome & Principe">Sao Tome & Principe</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Serbia">Serbia</option>
<option value="Seychelles">Seychelles</option>
<option value="Shetland Isles">Shetland Isles</option>
<option value="Sierra Leone">Sierra Leone</option>
<option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="Solomon Islands">Solomon Islands</option>
<option value="Somalia">Somalia</option>
<option value="Somaliland Rep. Of">Somaliland Rep. Of</option>
<option value="South Africa">South Africa</option>
<option value="Spain">Spain</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="St Barthelemy">St Barthelemy</option>
<option value="St Eustatius">St Eustatius</option>
<option value="St Kitts">St Kitts</option>
<option value="St Lucia">St Lucia</option>
<option value="St Maarten">St Maarten</option>
<option value="St Vincent">St Vincent</option>
<option value="Sudan">Sudan</option>
<option value="Suriname">Suriname</option>
<option value="Swaziland">Swaziland</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syria">Syria</option>
<option value="Tahiti">Tahiti</option>
<option value="Taiwan">Taiwan</option>
<option value="Tajikistan">Tajikistan</option>
<option value="Tanzania">Tanzania</option>
<option value="Thailand">Thailand</option>
<option value="Togo">Togo</option>
<option value="Tonga">Tonga</option>
<option value="Trinidad & Tobago">Trinidad & Tobago</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Turkmenistan">Turkmenistan</option>
<option value="Turks & Caicos Islands">Turks & Caicos Islands</option>
<option value="Tutuila Island">Tutuila Island</option>
<option value="Tuvalu">Tuvalu</option>
<option value="Uganda">Uganda</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Emirates">United Arab Emirates</option>
<option value="United Kingdom">United Kingdom</option>
<option value="Uruguay">Uruguay</option>
<option value="USA">USA</option>
<option value="Uzbekistan">Uzbekistan</option>
<option value="Vanuatu">Vanuatu</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<option value="Virgin Islands">Virgin Islands</option>
<option value="Virgin Islands">Virgin Islands</option>
<option value="Yap Island">Yap Island</option>
<option value="Yemen">Yemen</option>
<option value="Zambia">Zambia</option>
<option value="Zimbabwe">Zimbabwe</option>

			</select>


		</td>

		<td><span class="bluetexts"><font size="1" face="arial"></font></span></td>
        </tr>

	<tr>
          <td><font size="1" face="arial" color="white" align="top" span style="line-height:16px;">.</font></td>

        </tr> 



        <tr>
          <td><span class="texts" width="200"><strong>Weight of Package(kg)</strong></span></td>
		<td><input name="weight" type="text" class="contact_input" id="input2" value=""/></td>
		<td width="200"><span class="bluetexts"><font size="1" face="arial"></font></span></td>

        </tr> 

	<tr>
          <td><font size="1" face="arial" color="white" align="top" span style="line-height:16px;">.</font></td>

        </tr> 





          <td><span class="texts" width="250"><strong>Package Size</strong></span></td>
		<td><input name="length" type="text" class="input2" style="width:50px;" id="input3" onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'length(cm)':this.value;" value="length(cm)"/>
		<input name="width" type="text" class="input2" style="width:50px;" id="input3" onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'width(cm)':this.value;" value="width(cm)"/>
		<input name="height" type="text" class="input2" style="width:50px;" id="input3" onclick="this.value = '';" onfocus="this.select()" onblur="this.value=!this.value?'height(cm)':this.value;" value="height(cm)"/>
		<td width="250"><span class="bluetexts"><font size="1" face="arial"></font></span></td>
		
		<td></td>
        </tr>

	<tr>
          <td><span class="texts"></span></td>
		<td></td>
		<td width="250"></td>

        </tr> 



</table>


<input name="getquote" type="submit" class="getquote_btn" id="getquote" value="" />

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


















</div>         
              </div>





              <div class="TabbedPanelsContent" style="color: #666666;font-family: Arial,Helvetica,sans-serif;font-size: 12px;">






<h2>Prohibited Items</h2>
<div style="height:175px;width:667px;border:1px solid #ccc;overflow:auto;padding-top:5px;padding-left:5px;">
<strong>GENERAL PROHIBITIONS AND RESTRICTIONS</strong>
<p>Prohibited items are based on our preferred courier list of items they will not courier under EU & UK legislation.</P>  
<p>Any queries regarding possible prohibited items can be directed to info@parcelflow.co.uk.</p>
<strong>DANGEROUS GOODS</strong><br />
<p><strong>Total prohibitions - UK , import, export and transit</strong></p>
<p>Dangerous goods are defined as those goods which meet the criteria of 1 or more of 9 UN hazard classes. These classes relate to the type of hazard and are detailed below.</p>
<p>All dangerous goods are prohibited goods.</p>
<p><strong>Class 1 - Explosives</strong></p>
<p>Any chemical compound, mixture or device capable of producing an explosive-pyrotechnic effect, with substantial instantaneous release of heat and gas. All explosives are prohibited. Examples: Ammunition, Blasting caps, Christmas cracker snaps, Fireworks, Flares, Fuses, Igniters, Nitro-glycerine etc.</p>
<p><strong>Class 2 - Gases compressed, liquefied or dissolved under pressure</strong></p>
<p></p>Permanent gases, which cannot be liquefied at ambient temperatures; liquefied gases, which can become liquid under pressure at ambient temperatures; dissolved gases, which are dissolved under pressure in a solvent.
 <ol><li>All flammable compressed gases are prohibited.Examples: Blowlamps, Butane, Cigarette lighters, Ethane, Gas cylinders for camping stoves, Hydrogen, Methane, Propane etc.</li>
      <li>All toxic compressed gases are prohibited.Examples: Chlorine, Fluorine etc.</li>
      <li>All non-flammable compressed gases are prohibited,Examples: Carbon dioxide, Neon, Nitrogen, Fire extinguishers containing such gases etc.</li>
      <li>All aerosols are prohibited.</li></ol></p>
<p><strong>Class 3 - Flammable liquids</strong></p>
<p>
Liquids, mixtures of liquids, or liquids containing solids in solution or suspension which give off a flammable vapour. Any liquid with a closed cup flash point below 60.5°C is prohibited.
<br />Examples: Acetone, Benzene, Cleaning compounds, Gasoline, Lighter fuel, Paint thinners and removers, Petroleum, Solvents etc.</p>

<p><strong>Class 4 - Flammable Solids</strong></p>
<p>
Substances liable to spontaneous combustion. Substances which, in contact with water, emit flammable gases. Solid materials which are liable to cause fire by friction, absorption of water, spontaneous chemical changes, or retained heat from manufacturing or processing, or which can be readily ignited and burn vigorously.
Examples: Calcium carbide, Cellulose nitrate products, Matches (any type including safety), Metallic magnesium, Nitro-cellulose based film, Phosphorous, Potassium, Sodium, Sodium hydride, Zinc powder, Zirconium hydride etc.
</p>
<p><strong>Class 5 - Oxidizing substances and organic peroxides</strong></p>
<p>
Though not necessarily combustible themselves, these substances may cause or contribute to combustion of other substances. They may also be liable to explosive decomposition, react dangerously with other substances, and be injurious to health. All oxidizing substances and organic peroxides are prohibited.
<br />Examples: Bromates, Chlorates, Components of fibreglass repair kits, Nitrates, Perchlorates, Permanganates, Peroxides etc.
</p>
<p><strong>Class 6 - Toxic and infectious substances</strong></p>
<p>Substances liable to cause death or injury if swallowed or inhaled, or by skin contact. All toxic substances are prohibited.
<br />Examples: Arsenic, Beryllium, Cyanide, Fluorine, Hydrogen Solenoid, Infectious substance containing micro-organisms or their toxins which are known or suspected to cause disease, Mercury, Mercury salts, Mustard gas, Nitrobenzene, Nitrogen dioxide, Pesticides, Poisons, Rat poison. Pathogens in Risk Groups 4, and selected Risk Group 3 pathogens listed in Schedule 9, part 5 of the latest edition of the Control of Substances Hazardous to Health Regulations are prohibited.
<br />Examples: Ebola, Foot and mouth disease, Environmental, clinical and medical waste.</p>
<p><strong>Class 7 - Radioactive material</strong></p>
<p>All material and samples that are classified as radioactive using Table 2-12 of latest edition of the International Civil Aviation Organisation's Technical Instructions are prohibited.
<br />Examples: Fissile material (Uranium 235, etc), Radioactive waste material, Thorium or Uranium ores, etc.</p>
<p><strong>Class 8 - Corrosives</strong></p>
<p>Substances which can cause severe damage by chemical action to living tissue, other freight, or the means of transport. All corrosive substances are prohibited.
<br />Examples: Aluminium chloride, Caustic soda, Corrosive cleaning fluid, Corrosive rust remover/preventative, Corrosive paint remover, Electric storage batteries, Hydrochloric acid, Nitric acid, Sulphuric acid etc.</p>
<p><strong>Class 9 - Miscellaneous dangerous goods</strong></p>
<p>Substances which present dangers not covered elsewhere.
<br />Examples: Asbestos, Dry ice (solid carbon dioxide), Magnetised material with a magnetic field strength of 0.159 A/m or more at a distance of 2.1m from the outside of the package.
</p>
<p><strong>ARMS AND AMMUNITION</strong></p>
All types of ammunition are prohibited from being sent using any of our services. 
Further information about UK firearms law can be obtained from the Home Office.Tel: 020 7035 4848Email: public.enquiries@homeoffice.gsi.gov.uk

<p><strong>OTHER PROHIBITED GOODS</strong></p>
<p><strong>Drugs</strong><br />
Controlled drugs may not be sent by any Parcelforce Worldwide service. Those discovered in transit will be stopped, and handed to Customs or the Police, who may take legal action against the sender and/or recipient. Examples: Cocaine, Cannabis resin, LSD, Narcotics, Morphine, Opium, Psychotropic substances etc.</p>
<p><strong>Filth</strong><br />
Foul or disgusting material is prohibited.</p>
<p><strong>Human and animal remains</strong><br />
Human and animal remains (including ashes) are prohibited.</p>
<p><strong>Indecent, obscene or offensive articles</strong><br />
Indecent, obscene or offensive communications, prints, photographs, books or other articles, and packets bearing grossly offensive, indecent or obscene words, marks or designs are prohibited. Those discovered in transit will be stopped, and handed to Customs or the Police, who may take legal action against the sender and/or recipient.</p>
<p><strong>Lottery tickets</strong><br />
Tickets and related advertisements for illegal lotteries are prohibited.</p>
<p><strong>Miscellaneous manufactured articles</strong><br />
Goods made in foreign prisons, except those imported for a non-commercial purpose of a kind not manufactured in the United Kingdom , or those in transit.</p>
<p><strong>OTHER RESTRICTED GOODS</strong></p>
<p><strong>Alcoholic beverages</strong><br />
Alcoholic content should not be greater than 70%. Alcohol that will result in excise duty cannot be sent on the globalexpress service and to certain destinations on the globalpriority and globalvalue services.</p>
<p><strong>Batteries</strong><br />
These articles may only be posted in their retail packaging, still sealed and in good condition.</p>
<p><strong>Christmas crackers</strong><br />
May only be posted in complete made-up form and in their retail packaging.</p>
<p><strong>Counterfeit currency and postage stamps</strong><br />
Postage stamps are prohibited unless franked or no longer usable for postage purposes. Counterfeit currency is prohibited</p>
<p><strong>Diagnostic specimens</strong><br />
All diagnostic specimens must be posted in packaging that complies with Packing Instructions 650. The total sample volume/mass in any package shall not exceed 50ml/g. Diagnostic specimens are only permitted for destinations within the United Kingdom.</p>
<p><strong>Infectious substances</strong><br />
Infectious substances assigned to Category A are prohibited.</p>
<p><strong>International export licences and international packaging</strong><br />
Items requiring special licence or permit for transportation, importation or exportation; or consignments with a declared value for customs in excess of that permitted for the particular destination should not be sent on any international service. Please note: Any items that are wet, leaking or emit an odour of any kind cannot be sent on any of our services.</p> 
<p><strong>Living creatures</strong><br />
No living creatures will be handled by Parcel Flow.</p>
<p><strong>Misleading endorsements</strong><br />
Parcels must not bear words, marks or designs which are unauthorised and which may reasonably lead the recipient to believe that the packet has been sent On Her Majesty's Service.</p>
<p><strong>Perishable articles and foodstuffs</strong><br />
Fresh fruit, meat, fish and other perishable articles should be able to withstand a journey of up to 2 days and must be sent by guaranteed next day service as a minimum requirement within the UK . Packages must be clearly labelled "PERISHABLE".Packages of fish should be smoked or chilled, and sealed in vacuum packs before consignment. In all cases they must be enclosed in adequate polystyrene containment to prevent contamination. It is the responsibility of the shipper to package all perishable articles in such a manner that during transport within the system the contents are kept at an appropriate temperature that is unlikely to give rise to a risk to health. It is prohibited to export any foodstuffs, whether perishable or not, to certain destinations on our courier service list.  Please email us in advance, at info@parcelflow.co.uk</p>
<p><strong>Prescription drugs</strong><br />
Prescription drugs sent for medical or scientific purposes, for example from a medical practitioner to a hospital, must contain the address of the sender in case of non-delivery, so that they may be returned without delay. The properties of these drugs, should not meet any of the criteria of the 9 UN hazard classes when classified by the sender. Drugs in prescription quantities may be sent by private individuals in the case of emergencies. In all cases, the sender's address must be included on the inside of the package.</p>
<p><strong>Sharp objects</strong><br />
These items may only be posted if they are packaged appropriately so that they do not present a risk to employees, other packages or recipients.</p>
<p><strong>Financial documents</strong><br />
Money - bankers drafts, current bank notes, currency notes or coins, credit cards, debit cards, uncrossed postal orders which do not state to whom they are to be paid, cheques or dividend warrants which are uncrossed and made payable to the bearer; bearer securities including share warrants, scrips, or subscription certificates, bonds or relative coupons, unfranked postage or revenue stamps, (except a revenue stamp embossed or impressed on an instrument which has been executed); coupons, vouchers, tokens, lottery tickets, scratch cards or similar documents which can be exchanged themselves or with any other document for money, goods or services; national insurance stamps; all tickets, including travel and events.</p> 
<p><strong>Works of art</strong><br />
Works of art cannot be exported to certain destinations on the our courier services list. Works of art are excluded from compensation for loss and damage with most couriers although they can be sent.</p>
<p><strong>Plants</strong><br />
We do not forward life plants.</p>
</div>













</div>
              <div class="TabbedPanelsContent" style="color: #666666;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 12px;">




<P style="width:660px;">Parcel Flows priority is always to find the best suitable shipping option for ALL its customers.  We have established very close relations to a select number of courier companies who provide best value for money to our members.</P>
<P style="width:660px;">Transit times reflect YOUR shipping option, and will reflect in cost.</P>
<table width="500" border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td><strong>Service</strong></td>
    <td><strong>Transit Time</strong></td>
  </tr>
  <tr>
    <td>Parcel Flow Air Express</td>
    <td>2 Days</td>
  </tr>
  <tr>
    <td>Parcel Flow Europe by road</td>
    <td>3-4 Days</td>
  </tr>
  <tr>
    <td>Parcelforce Priority International</td>
    <td>2 Days.</td>
  </tr>
  <tr>
    <td>DHL Air Express</td>
    <td>1 Days.</td>
  </tr>
    <tr>
    <td>DHL Road Express</td>
    <td>2 Days.</td>
  </tr>
  </table>
<p style="width:660px;">Note:  Parcel Flow provides same day turn around on all parcels arriving at our depot.  We pride ourselves in processing and forwarding parcels as quickly and efficiently as possible.  </p>





















</div>
              <div class="TabbedPanelsContent" style="display:none;width:730px; height:247px; margin:0 auto; margin-bottom:40px; padding:30px 0 0 50px;color: #666666;font-family: Arial,Helvetica,sans-serif;font-size: 12px;">
<p>£20 of carriage guarantee cover FREE</p>
+ £0.14 for £50 of carriage guarantee cover<br>
+ £0.99 for £100 of carriage guarantee cover<br>
+ £1.49 for £150 of carriage guarantee cover<br>
+ £1.69 for £175 of carriage guarantee cover<br>
+ £2.49 for £200 of carriage guarantee cover<br>
+ £3.99 for £300 of carriage guarantee cover<br>
+ £5.99 for £400 of carriage guarantee cover<br>
+ £7.99 for £500 of carriage guarantee cover<br>
+ £9.99 for £600 of carriage guarantee cover<br>
+ £12.49 for £700 of carriage guarantee cover<br>
+ £14.99 for £800 of carriage guarantee cover<br>
+ £17.49 for £900 of carriage guarantee cover<br>
+ £19.99 for £1000 of carriage guarantee cover<br>



</div>
            </div>
          </div>
        </div>
        
        <div class="panel_right"></div>
        
        </div>
        

        


        
  </div>
</div>
<div class="steps_container"></div>
<div id="footer"> <a href="index.php">Home</a>    <a href="how-it-works.php">How It Works</a>    <a href="faqs.php">FAQ</a>    <a href="signup.php">Sign Up</a>    <a href="quick-quote.php">Quick quote</a>    <a href="contact.php">Contact
  </a><br />
  Copyright © 2020 Parcel Flow. All Rights Reserved
<script type="text/javascript">
<!--
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
//-->
</script>
</body>
</html>


