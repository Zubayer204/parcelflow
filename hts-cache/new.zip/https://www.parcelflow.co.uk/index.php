<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="google-site-verification" content="3g8Fm11QAhaRn_Yskm9KP6ectKPpDSbw_fdBvKfDNQ4" />
<link rel="icon" type="image/x-icon" href="new_images/char.png" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="keywords" content="parcel forwarding, forwarding service, package forwarding, packet forwarding, uk mailing address, international parcel shipping, uk postal address"/>
<meta name="description" content="
Free UK address for all your UK online purchases if you sign up today. No hidden fees or subscription charges, low cost shipping. Parcel Forwarding from UK to Europe, US, International. Amazon UK, ebay UK and all your favourite UK brands. Will deliver goods internationally.  You shop, we ship.  Parcel Flow UK."/>
<title>UK Shipping Address and Depot | Parcel Forwarding Service| Parcel Flow</title>
<!--<link href="style.css" rel="stylesheet" type="text/css" />-->
<script type="text/javascript">
<![CDATA[
var scRec=document.createElement('SCRIPT');
scRec.type='text/javascript';
scRec.src="//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js";
document.getElementsByTagName('head')[0].appendChild(scRec);
]]>
</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48615823-1', 'parcelflow.co.uk');
  ga('send', 'pageview');

</script>


<link rel="stylesheet" type="text/css" href="new_css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="new_css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="new_css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="new_css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="new_css/style.css">
<link rel="stylesheet" type="text/css" href="new_css/style_login.css">
<link rel="stylesheet" type="text/css" href="jquery.bxslider.css">
<script type="text/javascript" src="new_js/jquery.min.1.11.js"></script> 
<script type="text/javascript" src="new_js/bootstrap.min.js"></script> 
<script type="text/javascript" src="new_js/jquery.min.js"></script>
<script type="text/javascript" src="new_plugins/jquery.fitvids.js"></script>
<script type="text/javascript" src="new_plugins/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="new_js/jquery.bxslider.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<script type="text/javascript">
//var j = jQuery.noConFlict();
  jQuery(document).ready(function(){
    
 jQuery('.bxslider').bxSlider({
  buildPager: function(slideIndex){
    switch(slideIndex){
      case 0:
        return '<div class="bullets"><span class="badge" >1</span> <p>get a uk address</p></div>';
      case 1:
        return '<div class="bullets"><span class="badge" >2</span> <p>shop all stores</p></div>';
      case 2:
        return '<div class="bullets"><span class="badge" >3</span> <p>get email notification</p></div>';
        case 3:
        return '<div class="bullets"><span class="badge" >4</span><p>recieve  anywhere</p></div>';
    }
  }
});
});
</script>

<body>


<div class="top-sec">
  <div class="container">
    <div class="row nomargin" style="z-index: 99999999;"> <img src="new_images/header-logo.png" class="img-responsvie"> <a href="#" class="btn btn-login" id="loginform">Login</a>
      <div class="login" style="margin-left:770px;">
        <div class="arrow-up"></div>
        <div class="formholder">
          <div class="border" style="border: 1px red solid;margin: 2px;    border-radius: 5px;">
            <div class="randompad">
              <div class="title" style="text-align:center">Login</div>
              <br>
              <form name="register" method="post" action="/">
              <fieldset style="margin-top: -15px;padding-left: 3px;padding-right: 8px;padding-bottom: 5px;padding-top: 0px;">
                Email:
                <input name="loginemail" type="email" value="" placeholder="admin@admin.com"/>
                <br>
                Password:
                <input name="loginpassword" type="password" placeholder="*****"/>
                <br>
                <div class="col-sm-4 lpad"><input name="login" type="submit" style="background:#8BB03E;" value="Login" /></div>
<!--<div class="col-sm-8 lpad"><input type="submit" name="forgot" class="fget" value="Forgot Password?" /></div > -->

<div class="col-sm-8 lpad">
<a href="forgot1.php" class="fget" value="Forgot Password?">Forgot Password?</a>
</div>
              </fieldset>
             </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>






<!--

<div class="col-sm-8 lpad">
<a href="forgot1.php" class="fget" value="Forgot Password?">Forgot Password?</a>
</div>

-->

<div class="menu-sec">
  <div class="container">
    <nav class="navbar navbar-default"> 
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      
      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li><a href="index.php">HOME</a></li>
          <li><a href="how-it-works.php">HOW It works</a></li>
          <li><a href="amazon-return.html">services</a></li>
          <li><a href="rewards.php">rewards</a></li>
          <li><a href="faqs.php">faqs</a></li>
          <li><a href="signup.php">signup</a></li>
          <li><a href="quick-quote.php">quick quote</a></li>
          <li><a href="blog">blog</a></li>
          <li><a href="contact.php">Contact Us</a></li>
        </ul>
      </div>
      <!-- /.navbar-collapse --> 
    </nav>
  </div>
</div>
<div class="slider-sec">
  <div class="container">



<ul class="bxslider">
  <li><img src="new_images/img-01.jpg" /></li>
  <li><img src="new_images/img-02.jpg" /></li>
  <li><img src="new_images/img-03.jpg" /></li>
  <li><img src="new_images/img-04.jpg" /></li>
</ul>

</div>
</div>
<div class="main-sec">
  <div class="container">
    <div class="col-md-8 col-sm-8 col-xs-12 leftside">
      <div class="col-md-4"> <img src="new_images/join.png" class="img-responsive"> <a href="signup.php" class="btn btn-link">Join Now</a> </div>
      <div class="col-md-4"> <img src="new_images/learn.png" class="img-responsive"> <a href="how-it-works.php" class="btn btn-link">Learn more</a> </div>
      <div class="col-md-4"> <img src="new_images/testi.png" class="img-responsive"> <a href="testimonial.php" class="btn btn-link">Testimonials</a> </div>
      <div class="clearfix"></div>
      <h3>Get A Free UK address and get your online purchases delivered to your home address anywhere!</h3>
      <p> Parcel Flow provides a free UK shipping address that members can use when registering and shopping online with websites such as ebay UK, Amazon UK & many more. Parcel Flow simply takes delivery of your goods and forwards them on to you whereever you live in the world. The process is simple, affordable and reliable. We have partnered with leading international couriers to give excellent discount courier deals, all done in a friendly efficient manner with our well trained customer care agents.</p>
      <h3>So why choose us for your UK online purchases?</h3>
      <small>There are several good reasons and here are a few...</small>
      <ul>
        <li>We are the only Forwarder to offer a Free UK address- no membership charges- Ever!</li>
        <li>We offer free handling on your first order.</li>
        <li>We wont be beaten on price- check our 'price promise guarantee'.</li>
        <li> We provide parcel consolidation & re-packaging that genuinely saves YOU money.</li>
        <li>Fast Secure payment through Paypal.</li>
        <li>Great customer Service- You always get assigned your very own parcel handler for one to one friendly, professional communication- always there with a quick update on your order. </li>
        <li>We offer a loyalty points system that provides free shipping & or free handling, through our loyalty points scheme.</li>
        <li>Our members account management system is simple and easy to use.</li>
        <li>We offer a quick quote that gives you an idea of pricing before you shop UK online, no hidden surprises.</li>
        <li>We simply deliver anywhere.</li>
      </ul>
      <div class="row" style="text-align: center;margin-top: 110px"> <a href="signup.php" class="btn signup">Signup Today and give us a try!!</a>
        <p class="more-info">For more information Like Our <a href="https://www.facebook.com/parcelflowuk">Facebook</a> Page</p>
      </div>
    </div>
<!--    <div class="col-md-4 col-sm-4 col-xs-12 rightside"> <a href="virtual-office.html"><img src="new_images/virtualoffice.png" class="img-responsive"></a> -->
<div class="col-md-4 col-sm-4 col-xs-12 rightside"> <a href="virtual-office.php"><img src="new_images/virtualoffice.png" class="img-responsive"></a>
      <div class="clearfix"></div>
      <a href="amazon-return.html"><img src="new_images/amazon.png" class="img-responsive"></a>
      <div class="clearfix"></div>
      <a href=""><img src="new_images/gurantee.png" class="img-responsive"></a>
      <div class="clearfix"></div>
      <a href=""><img src="new_images/store.png" class="img-responsive"></a>
      <div class="clearfix"></div>
      <img src="new_images/account.png" class="img-responsive"> </div>
  </div>
</div>
<footer class="footer-sec">
  <div class="container">
    <div class="row">
      <div class="footer-menu">
        <ul class="col-md-3 col-sm-3 col-xs-6">
          <li>ABOUT</li>
          <li><a href="blog">Blog</a></li>
          <li><a href="testimonial.php">testimonials</a></li>
          <li><a href=""></a></li>
        </ul>
        <ul class="col-md-3 col-sm-3 col-xs-6">
          <li>SERVICES</li>
          <li><a href="signup.php">Virtual Office</a></li>
          <li><a href="index.php">Parcel Forwarding</a></li>
          <li><a href="amazon-returns.html">Amazon Returns</a></li>

        </ul>
        <ul class="col-md-3 col-sm-3 col-xs-6">
          <li>BESPOKE SERVICES</li>
          <li><a href="personal-shopper.html">personal shopper</a></li>
          <li><a href="signup.php">gift wrapping</a></li>
          <li><a href="signup.php">repackaging</a></li>
        </ul>
        <ul class="col-md-3 col-sm-3 col-xs-6" >
          <li>OUR TERMS</li>
          <li><a href="terms.html">terms and privacy</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="copyright-sec">
    <div class="container">
      <div class="row" style="padding: 15px 0px; ">
        <div class="col-md-8">
          <p style="font-size: 18px; font-weight: bold;">&copy Copyright 2020 Parcel Flow. All Rights Reserved.</p>
          <p style="font-size: 12px;">Parcel Flow, Suite 10, 44-46 Elmwood Ave, Co. Antrim, Belfast, BT9 6AZ, United Kingdom. 
            UK Mailing Address and Parcel Forwarding Service.</p>
        </div>
        <div class="col-md-4"> <img src="new_images/footer-logo.png" class="img-responsive"> </div>
      </div>
    </div>
  </div>
</footer>


<!-- Javascripts --> 

<script type="text/javascript" src="new_js/jquery-scrolltofixed-min.js"></script> 

<script type="text/javascript" src="new_js/index.js"></script>
</body>
</html>
